/**
 * @author Semih Turan
 * @since march 2024
 */
import view.LoginView;

public class App {
    public static void main(String[] args) {
        LoginView loginView = new LoginView();
    }
}
